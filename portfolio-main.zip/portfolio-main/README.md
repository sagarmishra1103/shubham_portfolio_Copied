## Portfolio
  
The porfolio is made using html,css, javascript & (soon Nodejs)
  
![image](https://user-images.githubusercontent.com/54644253/192871507-2285f3ba-59c2-44bf-bdff-1458fa4be37e.png)

## Live preview  
https://shubham7668.github.io/portfolio/


## Contributions
Contributions are always welcome!  

Fork repo, make changes, test, create a pull request.  

Please make sure to maintain authorship.  

(Will send goodies for exceptional changes:)


## Credits 
  
1)Anime png & gifs -> https://avatars.alphacoders.com/ 
  
2)Samarth Singh  

## LICENSE
  
[MIT](https://github.com/shubham7668/potfolio/blob/main/LICENSE)
